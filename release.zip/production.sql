/*
SQLyog 企业版 - MySQL GUI v8.14 
MySQL - 5.5.18 : Database - online_maker_manage_system
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`online_maker_manage_system` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `online_maker_manage_system`;

/*Table structure for table `allstatus` */

CREATE TABLE `allstatus` (
  `statusId` int(100) DEFAULT NULL,
  `comId` int(100) DEFAULT NULL,
  `selectCode` int(100) DEFAULT NULL,
  `payTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `company` */

CREATE TABLE `company` (
  `comId` int(100) DEFAULT NULL,
  `comName` varchar(1000) DEFAULT NULL,
  `comMon` int(100) DEFAULT NULL,
  `comMot` varchar(1000) DEFAULT NULL,
  `comFir` int(100) DEFAULT NULL,
  `comSec` int(100) DEFAULT NULL,
  `comThi` int(100) DEFAULT NULL,
  `comFou` int(100) DEFAULT NULL,
  `comFif` int(100) DEFAULT NULL,
  `comCEO` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `config` */

CREATE TABLE `config` (
  `faxPerTim` double DEFAULT NULL,
  `faxPerEng` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `engineering` */

CREATE TABLE `engineering` (
  `engId` int(100) DEFAULT NULL,
  `engName` varchar(1000) DEFAULT NULL,
  `engBing` int(100) DEFAULT NULL,
  `engMon` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `engstatus` */

CREATE TABLE `engstatus` (
  `engId` int(100) DEFAULT NULL,
  `comId` int(100) DEFAULT NULL,
  `engStatus` int(100) DEFAULT NULL,
  `engWork` varchar(1000) DEFAULT NULL,
  `statusId` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `useraccounts` */

CREATE TABLE `useraccounts` (
  `userId` int(100) DEFAULT NULL,
  `userEmail` varchar(1000) DEFAULT NULL,
  `userPass` varchar(100) DEFAULT NULL,
  `userName` varchar(1000) DEFAULT NULL,
  `isAdmin` tinyint(1) DEFAULT NULL,
  `userMotto` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `userannouncement` */

CREATE TABLE `userannouncement` (
  `Id` int(11) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Texts` longtext,
  `textTime` datetime DEFAULT NULL,
  `Title` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
