<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title>注册 - 在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "style.php";?>
<!-- css - 结束 --></head>
<body >
<!-- 导航栏 - 开始 -->
<?php include "header.php";?>
<!-- 导航栏 - 结束 -->
<form action="reLogin.php" method="post" onsubmit="return validateForm();">
<div class="login-box" >
    <h1><center>登录</center></h1><br>
    <h2><center><font size=3>邮箱: </font><input name="remail" type="textarea" /></center></h2><br>
    <h2><center><font size=3>密码: </font><input name="repass" type="password" /></center></h2><br>
    <center><font color=white><input type="submit"/></font>&#32;&#32;&#32;&#32;<font size=2><a href="account.php" >没有账号?点击注册</a></center></font>
</div>
</form>
<script>
function validateForm(){
    var x=document.forms["myForm"]["remail"].value;
    var atpos=x.indexOf("@");
    var dotpos=x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length){
        alert("不是一个有效的 e-mail 地址");
        return false;
    }
}
</script>
<!-- 脚注 - 开始 -->
<?php include "footer.php";?>
<!-- 脚注 - 结束 -->

</html></body>