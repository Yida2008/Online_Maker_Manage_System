<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../style.php";?>
<!-- css - 结束 -->

</head>
<body id="company">
<!-- 导航栏 - 开始 -->
<?php include "../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->

<?php

$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT *
        FROM company';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}

include ("../static/html_table.class.php");
// create object
$mytbl = new html_table();
// General Table properties
$mytbl->width = "60%";             // set table width;
$mytbl->cellspacing = 1;         // 1 is class's default value
$mytbl->cellpadding = 4;        // 4 is class's default value
$mytbl->border = 0;             // 0 is class's default value
$mytbl->rowcolor = "blue";     // table's rows colors...default is #FFCC99

// Set table's header row
$mytbl->display_header_row = TRUE;       // enable the option. Default is FALSE
$mytbl->set_bold_labels = TRUE;             // Default is TRUE
$mytbl->set_header_font_color="#000000"; // Default is #000000
$mytbl->set_header_font_face="Tahoma";   // default is Tahoma
$mytbl->set_header_bgcolor ="#FF9933";   // Default if $FFCC33

//Set row event
$mytbl->set_row_event = TRUE; // Default is FALSE
$mytbl->set_row_event_color = "#FF9900"; //Default is #9999FF

// Set table's rows alter colors
$mytbl->set_alter_colors = TRUE;        // Default is False
$mytbl->first_alter_color = "#E9E9E9"; // Default is #FFFFFF

// Add Font Tags in each cell
$mytbl->display_fonts = TRUE; // Default Is FALSE


// Builbing A Table - 4 colums, N rows

// 1st row Colspan 4
$myarr[0][0]["colspan"]= 4;
$myarr[0][0]["align"]  = "center";
$myarr[0][0]["text"]   = "公司列表";

$myarr[1][0]["text"]= "&nbsp";
$myarr[1][0]["align"]  = "center";
$myarr[1][0]["text"]="公司编号";
$myarr[1][1]["align"]  = "center";
$myarr[1][1]["text"]="公司名称";
$myarr[1][2]["align"]  = "center";
$myarr[1][2]["text"]="公司资金";
$myarr[1][3]["align"]  = "center";
$myarr[1][3]["text"]="公司格言";

##########embeded table##########################
$i = 2;
while($row=mysqli_fetch_row($retval)) {
    $Id = $row[0];
    $Name = $row[1];
    $Money = $row[2];
    $Motto = $row[3];

    ####################################
    // adding rows
    $ti = $i - 1;
    $myarr[$i][0]["width"] = 50;
    $myarr[$i][0]["align"] = "center";
    $myarr[$i][0]["bgcolor"] = "red";
    $myarr[$i][0]["text"]  = $Id;
    $myarr[$i][1]["width"] = 300;
    $myarr[$i][1]["align"] = "center";
    $myarr[$i][1]["text"]  = "<a href='/company/?$ti'>$Name</a>";
    $myarr[$i][2]["width"] = 100;
    $myarr[$i][2]["align"] = "center";
    $myarr[$i][2]["text"]  = $Money;
    $myarr[$i][3]["width"] = 300;
    $myarr[$i][3]["align"] = "center";
    $myarr[$i][3]["text"]  = $Motto;
    $i++;
}
// Building Html from array
$html = $mytbl->build_html_table( $myarr );

// 释放内存
mysqli_free_result($retval);
mysqli_close($conn);
?>
<center>
    <div id="all" >
    <?php
    echo($html);
    ?>
    </div>
</center>
<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../footer.php";?>
<!-- 脚注 - 结束 -->