<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../../../style.php";?>
<!-- css - 结束 -->

</head>
<body id="company">
<!-- 导航栏 - 开始 -->
<?php include "../../../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->
<?php

$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT count(*)
        FROM company';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}

$row = mysqli_fetch_row($retval);
$n = $row[0];

$url = $_SERVER["REQUEST_URI"];
$tmp=0;
for ($i = strlen($url)-1; $i >= 0; $i--) {
    if($url[$i] == '?') {
        $tmp=$i+1;
        break;
    }
}

$num = 0;
$tnum = 1;

for ($i = $tmp; $i < strlen($url); $i++) {
    $num += $tnum * ($url[$i] - '0');
    $tnum *= 10;
}

if($num == 0 || $num > $n) {
    header("Location: /company/");
} else {
    $sql = 'SELECT *
        FROM company';

    mysqli_select_db( $conn, 'online_maker_manage_system' );
    $retval = mysqli_query( $conn, $sql );
    if(! $retval ) {
        die('无法读取数据: ' . mysqli_error($conn));
    }
    $i = 1;
    while($row = mysqli_fetch_row($retval)) {
        if($i > $num) break;
        $Id[$i] = $row[0];
        $Name[$i] = $row[1];
        $Money[$i] = $row[2];
        $Motto[$i] = $row[3];
        $First[$i] = $row[4];
        $Second[$i] = $row[5];
        $Third[$i] = $row[6];
        $Fourth[$i] = $row[7];
        $Fifth[$i] = $row[8];
        $CEO[$i] = $row[9];
        $i++;
    }
    $i--;

    // 释放内存
    mysqli_free_result($retval);
    mysqli_close($conn);
}

?>

<center>
    <form action="submit.php" method="post">
        <input type="textarea" name="comId" value="<?php echo($Id[$i]);?>" hidden="true" />
        公司编号：<input type="textarea" name="comId" value="<?php echo($Id[$i]);?>" disabled="true" /><br>
        公司名称：<input type="textarea" name="comName" value="<?php echo($Name[$i]);?>" /><br>
        公司余额：<input type="textarea" name="comMon" value="<?php echo($Money[$i]);?>" /><br>
        公司格言：<input type="textarea" name="comMot" value="<?php echo($Motto[$i]);?>" /><br>
        工程部（编号）：<input type="textarea" name="comFir" value="<?php echo($First[$i]);?>" /><br>
        编程部（编号）：<input type="textarea" name="comSec" value="<?php echo($Second[$i]);?>" /><br>
        美术部（编号）：<input type="textarea" name="comThi" value="<?php echo($Third[$i]);?>" /><br>
        后勤部（编号）：<input type="textarea" name="comFou" value="<?php echo($Fourth[$i]);?>" /><br>
        宣传部（编号）：<input type="textarea" name="comFif" value="<?php echo($Fifth[$i]);?>" /><br>
        董事长（编号）：<input type="textarea" name="comCEO" value="<?php echo($CEO[$i]);?>" /><br>
        <input type="submit" value="完成修改" />
    </form>
</center>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../../../footer.php";?>
<!-- 脚注 - 结束 -->