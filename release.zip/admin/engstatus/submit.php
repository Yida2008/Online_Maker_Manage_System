<?php
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$ans = $_POST['get'];
$comId = $_POST['com'];
$engId = $_POST['eng'];
$sql = 'UPDATE engstatus
        SET engStatus=1
        WHERE statusId="'.$ans.'"';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据2: ' . mysqli_error($conn));
}

$sql = 'SELECT engMon
        FROM engineering
        WHERE engId="'.$ans.'"';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据2: ' . mysqli_error($conn));
}
while($row=mysqli_fetch_row($retval)) {$engMon = $row[0];}

$sql = 'SELECT faxPerEng
        FROM config';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据2: ' . mysqli_error($conn));
}
while($row=mysqli_fetch_row($retval)) {$faxPerEng = $row[0];}

$sql = 'SELECT comMon
        FROM company
        WHERE comId="'.$comId.'"';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据2: ' . mysqli_error($conn));
}
while($row=mysqli_fetch_row($retval)) {$comMon = $row[0];}

$sql = 'UPDATE company
        SET comMon="'.(int)((double)$comMon + (double)$engMon * (1.00 - $faxPerEng)).'"
        WHERE comId="'.$comId.'"';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据2: ' . mysqli_error($conn));
}
header("Location:".getenv('HTTP_REFERER'));

?>