<?php
$email = $_COOKIE["email"];
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT isAdmin
        FROM useraccounts
        WHERE userEmail = "'.$email.'"';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$isAdmin = 0;
while($row = mysqli_fetch_row($retval)) {
    $isAdmin =  $row[0];
}

?>
<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../style.php";?>
<!-- css - 结束 -->

</head>
<body>
<!-- 导航栏 - 开始 -->
<?php include "../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->

<?php
// 防止高级手段
if(!$isAdmin) die("<script>alert('权限不足!');</script>");
?>

<a href="engineer/">
<div class="banner-box" style="background-color:green; font-size:30px;">
    <dp style="position: relative; top:35%;">工程管理</dp>
</div>
</a>

<a href="company/">
<div class="banner-box" style="background-color:#ccffff; font-size:30px;">
    <dp style="position: relative; top:35%;">公司管理</dp>
</div>
</a>

<a href="account/">
<div class="banner-box" style="background-color:orange; font-size:30px;">
    <dp style="position: relative; top:35%;">用户管理</dp>
</div>
</a>

<a href="announce/">
<div class="banner-box" style="background-color:red; font-size:30px;">    
    <dp style="position: relative; top:35%;">公告管理</dp>
</div>
</a>

<a href="config/">
<div class="banner-box" style="background-color:purple; font-size:30px;">
    <dp style="position: relative; top:35%;">税收管理</dp>
</div>
</a>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../footer.php";?>
<!-- 脚注 - 结束 -->