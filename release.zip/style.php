<?php
echo('
<link href="/static/pace/themes/green/pace-theme-flash.css" rel="stylesheet" />
<link href="/static/head.css" rel="stylesheet" />
<script src=/static/pace/pace.min.js></script>
');
?>