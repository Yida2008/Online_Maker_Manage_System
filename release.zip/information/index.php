<?php

$url = $_SERVER["REQUEST_URI"];
$tmp=0;
for ($i = strlen($url)-2; $i >= 0; $i--) {
    if($url[$i] == '?') {
        $tmp=1;
        break;
    }
}
if($tmp) {
    include("other.php");
} else {
    include("my.php");
}

?>