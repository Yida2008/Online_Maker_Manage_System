<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../style.php";?>
<!-- css - 结束 -->

</head>
<body>
<!-- 导航栏 - 开始 -->
<?php include "../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->

<?php
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'root';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$email = $_COOKIE['email'];
$sql = 'SELECT *
        FROM useraccounts
        WHERE userEmail="'.$email.'"';
mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
while($row = mysqli_fetch_row($retval)) {
    $Id = $row[0];
    $Email = $row[1];
    $Pass = $row[2];
    $Name = $row[3];
    $Motto = $row[5];
}


?>
<center>
    <form action="submit.php" method="post">
        <input type="textarea" name="Id" value="<?php echo($Id);?>" hidden="true" />
        我的编号：<input type="textarea" name="Id" value="<?php echo($Id);?>" disabled="true" /><br>
        我的昵称：<input type="textarea" name="Name" value="<?php echo($Name);?>" /><br>
        我的邮箱：<input type="textarea" name="Email" value="<?php echo($Email);?>" /><br>
        我的密码：<input type="textarea" name="Pass" value="<?php echo($Pass);?>" /><br>
        我的格言：<input type="textarea" name="Motto" value="<?php echo($Motto);?>" /><br>
        <input type="submit" value="完成修改" />
    </form>
</center>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../footer.php";?>
<!-- 脚注 - 结束 -->