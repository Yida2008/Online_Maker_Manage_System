<?php
setcookie("email", '');
header("Location: /");
?>