<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../style.php";?>
<!-- css - 结束 -->

</head>
<body class="stars"id="company">
<!-- 导航栏 - 开始 -->
<?php include "../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->
<?php

$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT count(*)
        FROM company';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}

$row = mysqli_fetch_row($retval);
$n = $row[0];

$url = $_SERVER["REQUEST_URI"];
$tmp=0;
for ($i = strlen($url)-1; $i >= 0; $i--) {
    if($url[$i] == '?') {
        $tmp=$i+1;
        break;
    }
}

//slect
function selectSQL($SQL) {
    $dbhost = '124.156.134.23';  // mysql服务器主机地址
    $dbuser = 'omms';            // mysql用户名
    $dbpass = 'ajdts';          // mysql用户名密码
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
    if(! $conn ) {
        die('连接失败: ' . mysqli_error($conn));
    }
    // 设置编码，防止中文乱码
    mysqli_query($conn , "set names utf8");
    mysqli_select_db( $conn, 'online_maker_manage_system' );
    $retval = mysqli_query( $conn, $SQL );
    if(! $retval ) {
        die('无法读取数据: ' . mysqli_error($conn));
    }
    $i = 1;
    while($row = mysqli_fetch_array($retval)) {
        $res[$i] = $row;
        $i++;
    }
    return $res;
}
$num = 0;
$tnum = 1;

for ($i = $tmp; $i < strlen($url); $i++) {
    $num += $tnum * ($url[$i] - '0');
    $tnum *= 10;
}

if($num == 0 || $num > $n) {
    header("Location: /mycom/");
} else {
    $dbhost = '124.156.134.23';  // mysql服务器主机地址
    $dbuser = 'omms';            // mysql用户名
    $dbpass = 'ajdts';          // mysql用户名密码
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
    if(! $conn ) {
        die('连接失败: ' . mysqli_error($conn));
    }
    // 设置编码，防止中文乱码
    mysqli_query($conn , "set names utf8");
    mysqli_select_db( $conn, 'online_maker_manage_system' );
    $sql = 'SELECT *
        FROM useraccounts
        WHERE userId="'.$num.'"';
    $retval = mysqli_query( $conn, $sql );
    if(! $retval ) {
        die('无法读取数据: ' . mysqli_error($conn));
    }
    $i = 1;
    while($row = mysqli_fetch_row($retval)) {
        $Id = $row[0];
        $Email = $row[1];
        $Name = $row[3];
        $Motto = $row[5];
    }
    // 释放内存
    mysqli_free_result($retval);
    mysqli_close($conn);
}

?>
<div style="display: inline-block;margin-left:25%;color:white;margin-top:3%;border-radius:5px; width:40%; height:17%; background-color:orange;" >
<?php
$ti = $i - 1;
echo("<br>用户编号:  ".$Id.
"<br>用户名称:  ".
"<a href='/information/?$Id'>$Name</a>".
"<br>用户邮箱：  ".$Email.
"<br>用户格言:  ".$Motto."");
?>
</div>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../footer.php";?>
<!-- 脚注 - 结束 -->