﻿<?php
    $dbhost = '124.156.134.23';  // mysql服务器主机地址
    $dbuser = 'omms';            // mysql用户名
    $dbpass = 'ajdts';          // mysql用户名密码
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
    if(! $conn ) {
        die('连接失败: ' . mysqli_error($conn));
    }
    // 设置编码，防止中文乱码
    mysqli_query($conn , "set names utf8");
    
    $Name = $_POST["newname"];
    $email = $_POST["newmail"];
    $password = $_POST["newpass"];
    
    if($Name!=null && $email != null && $password != null){
        $sqlr = 'SELECT count(*)
                FROM useraccounts
                WHERE userEmail= "' . $email . '" || userName="'.$Name.'"';
        mysqli_select_db( $conn, 'online_maker_manage_system' );
        $retvalr = mysqli_query( $conn, $sqlr );
        if(mysqli_num_rows( $retvalr)) {     
            $rs=mysqli_fetch_array($retvalr);    
            //统计结果
            $count=$rs[0];
         }else{     
             $count=0;
         }
        if($count==1){
            header("Location: login.php");
        } else {
            $sqlr1 = 'SELECT count(*)
                     FROM useraccounts';
            mysqli_select_db( $conn, 'online_maker_manage_system' );
            $retvalr1 = mysqli_query( $conn, $sqlr1 );
            while($rs1=mysqli_fetch_array($retvalr1)) {$num=$rs1[0];}
            $sql = "INSERT INTO useraccounts ".
            "(userId, userEmail, userPass, userName, isAdmin, userMotto) ".
            "VALUES ".
            "('$num','$email','$password','$Name','0','这个人很懒，啥都没有留下……')";

            $retval = mysqli_query( $conn, $sql );
            if(! $retval ) {
                die('注册信息有误！ ');
            }
            header("Location: login.php");
        }
        mysqli_close($conn);
    } else {
        die("昵称/邮箱/密码 尚未填写完整，请重新填写!<br><a href='/account.php'>");
    }
?>