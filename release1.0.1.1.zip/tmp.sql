/*
SQLyog 企业版 - MySQL GUI v8.14 
MySQL - 5.5.18 : Database - online_maker_manage_system
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`online_maker_manage_system` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `online_maker_manage_system`;

/*Table structure for table `allstatus` */

DROP TABLE IF EXISTS `allstatus`;

CREATE TABLE `allstatus` (
  `statusId` int(100) DEFAULT NULL,
  `comId` int(100) DEFAULT NULL,
  `selectCode` int(100) DEFAULT NULL,
  `payTime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `allstatus` */

insert  into `allstatus`(`statusId`,`comId`,`selectCode`,`payTime`) values (1,1,1,'0000-00-00 00:00:00');

/*Table structure for table `company` */

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `comId` int(100) DEFAULT NULL,
  `comName` varchar(1000) DEFAULT NULL,
  `comMon` int(100) DEFAULT NULL,
  `comMot` varchar(1000) DEFAULT NULL,
  `comFir` int(100) DEFAULT NULL,
  `comSec` int(100) DEFAULT NULL,
  `comThi` int(100) DEFAULT NULL,
  `comFou` int(100) DEFAULT NULL,
  `comFif` int(100) DEFAULT NULL,
  `comCEO` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `company` */

insert  into `company`(`comId`,`comName`,`comMon`,`comMot`,`comFir`,`comSec`,`comThi`,`comFou`,`comFif`,`comCEO`) values (1,'Test_Of_One',1016,'我们不生产水，我们只是大自然的搬运工。',1,2,3,4,5,1),(2,'Test_Of_Two',731,'31232',2,1,2,3,4,1),(3,'Test_Of_Three',1000,'123',1,1,1,1,1,1);

/*Table structure for table `config` */

DROP TABLE IF EXISTS `config`;

CREATE TABLE `config` (
  `faxPerTim` double DEFAULT NULL,
  `faxPerEng` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `config` */

insert  into `config`(`faxPerTim`,`faxPerEng`) values (0.1,0.15);

/*Table structure for table `engineering` */

DROP TABLE IF EXISTS `engineering`;

CREATE TABLE `engineering` (
  `engId` int(100) DEFAULT NULL,
  `engName` varchar(1000) DEFAULT NULL,
  `engBing` int(100) DEFAULT NULL,
  `engMon` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `engineering` */

insert  into `engineering`(`engId`,`engName`,`engBing`,`engMon`) values (1,'测试',0,1000),(2,'2',0,32);

/*Table structure for table `engstatus` */

DROP TABLE IF EXISTS `engstatus`;

CREATE TABLE `engstatus` (
  `engId` int(100) DEFAULT NULL,
  `comId` int(100) DEFAULT NULL,
  `engStatus` int(100) DEFAULT NULL,
  `engWork` varchar(1000) DEFAULT NULL,
  `statusId` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `engstatus` */

insert  into `engstatus`(`engId`,`comId`,`engStatus`,`engWork`,`statusId`) values (1,2,0,NULL,1),(1,1,0,'f60148776840182674900ad210010587.vnd.xmind.workbook',2),(2,1,0,NULL,3);

/*Table structure for table `useraccounts` */

DROP TABLE IF EXISTS `useraccounts`;

CREATE TABLE `useraccounts` (
  `userId` int(100) DEFAULT NULL,
  `userEmail` varchar(1000) DEFAULT NULL,
  `userPass` varchar(100) DEFAULT NULL,
  `userName` varchar(1000) DEFAULT NULL,
  `isAdmin` tinyint(1) DEFAULT NULL,
  `userMotto` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `useraccounts` */

insert  into `useraccounts`(`userId`,`userEmail`,`userPass`,`userName`,`isAdmin`,`userMotto`) values (1,'1485879324@qq.com','xyd2008315','Yida_Xiang',1,'这个人很懒，啥都没有留下……'),(2,'2','2','2',0,'这个人很懒，啥都没有留下……'),(3,'3','3','3',0,'这个人很懒，啥都没有留下……'),(4,'4','4','4',0,'这个人很懒，啥都没有留下……'),(5,'5','5','5',0,'这个人很懒，啥都没有留下……'),(6,'6','6','6',0,'这个人很懒，啥都没有留下……'),(7,'7','7','7',0,'这个人很懒，啥都没有留下……'),(8,'1@qq.com','123','1234',0,'这个人很懒，啥都没有留下……'),(9,'2@qq.com','123','test1',0,'这个人很懒，啥都没有留下……');

/*Table structure for table `userannouncement` */

DROP TABLE IF EXISTS `userannouncement`;

CREATE TABLE `userannouncement` (
  `Id` int(11) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Texts` longtext,
  `textTime` datetime DEFAULT NULL,
  `Title` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

/*Data for the table `userannouncement` */

insert  into `userannouncement`(`Id`,`Email`,`Texts`,`textTime`,`Title`) values (1,'1485879324@qq.com','12312312\r\n\r\n- 321\r\n- 3123\r\n\r\n**32131**\r\n\r\n# 12','2020-12-19 19:53:29','测试'),(2,'1485879324@qq.com','234143241432','2020-12-19 19:55:02','测试2'),(3,'1485879324@qq.com','tset','2020-12-19 20:03:13','tete');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
