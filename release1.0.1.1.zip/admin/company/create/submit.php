<?php
$comId = $_POST["comId"];
$comName = $_POST["comName"];
$comMon = $_POST["comMon"];
$comMot = $_POST["comMot"];
$comFir = $_POST["comFir"];
$comSec = $_POST["comSec"];
$comThi = $_POST["comThi"];
$comFou = $_POST["comFou"];
$comFif = $_POST["comFif"];
$comCEO = $_POST["comCEO"];
if($comId == null || $comName == null || $comMon == null || $comMot == null || $comFir == null || $comSec == null || $comThi == null || $comFou == null || $comFif == null || $comCEO == null) {
    die("表单当中有空项，请重新填写！<a href='/admin/company/create/'>点击返回</a>");
}

$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
mysqli_select_db( $conn, 'online_maker_manage_system' );
$SQL = 'INSERT INTO company
        (comId,
        comName, 
        comMon, 
        comMot, 
        comFir, 
        comSec, 
        comThi, 
        comFou, 
        comFif, 
        comCEO)
        VALUES
        ("'.$comId.'", "'.$comName.'", "'.$comMon.'", "'.$comMot.'", "'.$comFir.'", "'.$comSec.'", "'.$comThi.'", "'.$comFou.'", "'.$comFif.'", "'.$comCEO.'")';
$retval = mysqli_query( $conn, $SQL );
if(! $retval ) {
    die('无法更新数据: ' . mysqli_error($conn));
}
header("Location: /admin/company/modify/");
?>