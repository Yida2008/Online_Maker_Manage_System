<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../../../style.php";?>
<!-- css - 结束 -->

</head>
<body>
<!-- 导航栏 - 开始 -->
<?php include "../../../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->
<?php

$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT count(*)
        FROM useraccounts';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}

$row = mysqli_fetch_row($retval);
$n = $row[0];

$url = $_SERVER["REQUEST_URI"];
$tmp=0;
for ($i = strlen($url)-1; $i >= 0; $i--) {
    if($url[$i] == '?') {
        $tmp=$i+1;
        break;
    }
}

$num = 0;
$tnum = 1;

for ($i = $tmp; $i < strlen($url); $i++) {
    $num += $tnum * ($url[$i] - '0');
    $tnum *= 10;
}

if($num == 0 || $num > $n) {
    header("Location: /admin/announce/modify/");
} else {
    $sql = 'SELECT *
        FROM userannouncement';

    mysqli_select_db( $conn, 'online_maker_manage_system' );
    $retval = mysqli_query( $conn, $sql );
    if(! $retval ) {
        die('无法读取数据: ' . mysqli_error($conn));
    }
    $i = 1;
    while($row = mysqli_fetch_row($retval)) {
        if($i > $num) break;
        $Id[$i] = $row[0];
        $Email[$i] = $row[1];
        $Texts[$i] = $row[2];
        $Time[$i] = $row[3];
        $Title[$i] = $row[4];
        $i++;
    }
    $i--;

    // 释放内存
    mysqli_free_result($retval);
    mysqli_close($conn);
}

?>

<center>
    <form action="submit.php" method="post">
        <input type="textarea" name="Id" value="<?php echo($Id[$i]);?>" hidden="true" />
        公告编号：<input type="textarea" name="Id" value="<?php echo($Id[$i]);?>" disabled="true" /><br>
        邮箱：<input type="textarea" name="Email" value="<?php echo($Email[$i]);?>" disabled="true" /><br>
        公告内容：<textarea name="Texts"><?php echo($Texts[$i]);?></textarea><br>
        发布时间：<input type="textarea" name="Time" value="<?php echo($Time[$i]);?>" disabled="true" /><br>
        公告标题：<input type="textarea" name="Title" value="<?php echo($Title[$i]);?>" /><br>
        <input type="submit" value="完成修改" />
    </form>
</center>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../../../footer.php";?>
<!-- 脚注 - 结束 -->