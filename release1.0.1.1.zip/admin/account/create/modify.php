<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../../../style.php";?>
<!-- css - 结束 -->

</head>
<body class="stars"id="company">
<!-- 导航栏 - 开始 -->
<?php include "../../../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->
<?php

$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT count(*)
        FROM useraccounts';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}

$row = mysqli_fetch_row($retval);
$num = $row[0] + 1;

// 释放内存
mysqli_free_result($retval);
mysqli_close($conn);

?>

<center>
    <form action="submit.php" method="post">
        <input type="textarea" name="userId" value="<?php echo($num);?>" hidden="true" />
        用户编号：<input type="textarea" name="userId" value="<?php echo($num);?>" disabled="true" /><br>
        用户邮箱：<input type="textarea" name="userEmail" value="" /><br>
        用户密码：<input type="textarea" name="userPass" value="" /><br>
        用户名称：<input type="textarea" name="userName" value="" /><br>
        是否为管理员：<input type="textarea" name="isAdmin" value="" /><br>
        所在公司（编号）：<input type="textarea" name="Company" value="" /><br>
        用户格言：<input type="textarea" name="Motto" value="" /><br>
        <input type="submit" value="完成创建" />
    </form>
</center>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../../../footer.php";?>
<!-- 脚注 - 结束 -->