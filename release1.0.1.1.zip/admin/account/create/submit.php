<?php
$userId = $_POST["userId"];
$userEmail = $_POST["userEmail"];
$userPass = $_POST["userPass"];
$userName = $_POST["userName"];
$isAdmin = $_POST["isAdmin"];
$Company = $_POST["Company"];
$Motto = $_POST["Motto"];
if($userId == null || $userEmail == null || $userPass == null || $userName == null || $isAdmin == null) {
    die("表单当中有空项，请重新填写！<a href='/admin/company/create/'>点击返回</a>");
}

$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
mysqli_select_db( $conn, 'online_maker_manage_system' );
$SQL = 'INSERT INTO useraccounts
        (userId,
        userEmail, 
        userPass, 
        userName, 
        isAdmin, 
        userCompany, 
        userMotto)
        VALUES
        ("'.$userId.'", "'.$userEmail.'", "'.$userPass.'", "'.$userName.'", "'.$isAdmin.'", "'.$Company.'", "'.$Motto.'")';
$retval = mysqli_query( $conn, $SQL );
if(! $retval ) {
    die('无法更新数据: ' . mysqli_error($conn));
}
header("Location: /admin/account/modify/");
?>