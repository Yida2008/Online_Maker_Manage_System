<?php
$email = $_COOKIE["email"];
$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT isAdmin
        FROM useraccounts
        WHERE userEmail = "'.$email.'"';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$isAdmin = 0;
while($row = mysqli_fetch_row($retval)) {
    $isAdmin =  $row[0];
}

?>
<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../../../style.php";?>
<!-- css - 结束 -->

</head>
<body>
<!-- 导航栏 - 开始 -->
<?php include "../../../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->

<?php
if(!$isAdmin) die("<script>alert('权限不足!');</script>");
?>

<?php
$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT *
        FROM engineering';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$i = 1;
while($row = mysqli_fetch_row($retval)) {
    $Id[$i] = $row[0];
    $Name[$i] = $row[1];
    $Bing[$i] = $row[2];
    if($Bing[$i] == null) $Bing[$i] = "暂无人员";
    $Money[$i] = $row[3];
    $i++;
}
$tmp = $i;
include ("../../../static/html_table.class.php");
// create object
$mytbl = new html_table();
// General Table properties
$mytbl->width = "70%";             // set table width;
$mytbl->cellspacing = 1;         // 1 is class's default value
$mytbl->cellpadding = 4;        // 4 is class's default value
$mytbl->border = 0;             // 0 is class's default value
$mytbl->rowcolor = "blue";     // table's rows colors...default is #FFCC99


// Set table's header row
$mytbl->display_header_row = TRUE;       // enable the option. Default is FALSE
$mytbl->set_bold_labels = TRUE;             // Default is TRUE
$mytbl->set_header_font_color="#000000"; // Default is #000000
$mytbl->set_header_font_face="Tahoma";   // default is Tahoma
$mytbl->set_header_bgcolor ="#87CEFA";   // Default if $FFCC33

//Set row event
$mytbl->set_row_event = TRUE; // Default is FALSE
$mytbl->set_row_event_color = "#FF9900"; //Default is #9999FF

// Set table's rows alter colors
$mytbl->set_alter_colors = TRUE;        // Default is False
$mytbl->first_alter_color = "#E9E9E9"; // Default is #FFFFFF

// Add Font Tags in each cell
$mytbl->display_fonts = TRUE; // Default Is FALSE


// Builbing A Table - 4 colums, N rows

// 1st row Colspan 4
$myarr[0][0]["colspan"]= 10;
$myarr[0][0]["align"]  = "center";
$myarr[0][0]["text"]   = "工程列表";

$myarr[1][0]["text"]= "&nbsp";
$myarr[1][0]["align"]  = "center";
$myarr[1][0]["text"]="工程编号";
$myarr[1][1]["align"]  = "center";
$myarr[1][1]["text"]="工程名称";
$myarr[1][2]["align"]  = "center";
$myarr[1][2]["text"]="工程丙方";
$myarr[1][3]["align"]  = "center";
$myarr[1][3]["text"]="工程报酬";
for ($i = 2; $i <= $tmp; $i++) {
    $ti = $i - 1;
    $myarr[$i][0]["width"] = 50;
    $myarr[$i][0]["align"] = "center";
    $myarr[$i][0]["bgcolor"] = "#48D1CC";
    $myarr[$i][0]["text"]  = $Id[$ti];
    $myarr[$i][1]["width"] = 200;
    $myarr[$i][1]["align"] = "center";
    $myarr[$i][1]["text"]  = "<a href='/market/eng/?$ti'>".$Name[$ti]."</a>";
    $myarr[$i][2]["width"] = 100;
    $myarr[$i][2]["align"] = "center";
    $myarr[$i][2]["text"]  = $Bing[$ti];
    $myarr[$i][3]["width"] = 300;
    $myarr[$i][3]["align"] = "center";
    $myarr[$i][3]["text"]  = $Money[$ti];
    $myarr[$i][9]["width"] = 100;
    $myarr[$i][9]["align"]  = "center";
    $myarr[$i][9]["text"]="<a href='?$ti'>修改</a>";
}

// Building Html from array
$html = $mytbl->build_html_table( $myarr );

// 释放内存
mysqli_free_result($retval);
mysqli_close($conn);
?>

<center>
    <div id="all" >
    <?php
    echo($html);
    ?>
    </div>
</center>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../../../footer.php";?>
<!-- 脚注 - 结束 -->