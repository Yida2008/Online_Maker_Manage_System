<?php
$email = $_COOKIE["email"];
$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT isAdmin
        FROM useraccounts
        WHERE userEmail = "'.$email.'"';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$isAdmin = 0;
while($row = mysqli_fetch_row($retval)) {
    $isAdmin =  $row[0];
}

?>
<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../../style.php";?>
<!-- css - 结束 -->

</head>
<body>
<!-- 导航栏 - 开始 -->
<?php include "../../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->

<?php
if(!$isAdmin) die("<script>alert('权限不足!');</script>");

$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT *
        FROM config';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
while($row=mysqli_fetch_row($retval)) {
    $faxPerTim = $row[0];
    $faxPerEng = $row[1];
}

?>

<center>
    <form action="submit.php" method="post">
        每次收税时费用占总虚拟币的百分比（小数）：<input type="textarea" name="faxPerTim" value="<?php echo($faxPerTim);?>" /><br>
        完成工程时交税占总工程费的百分比（小数）：<input type="textarea" name="faxPerEng" value="<?php echo($faxPerEng);?>" /><br>
        <input type="submit" value="完成修改" />
    </form>
</center>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../../footer.php";?>
<!-- 脚注 - 结束 -->