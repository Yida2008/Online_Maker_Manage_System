<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../style.php";?>
<!-- css - 结束 -->

</head>
<body class="stars"id="company">
<!-- 导航栏 - 开始 -->
<?php include "../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->
<test>
<?php

$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
mysqli_select_db( $conn, 'online_maker_manage_system' );

$email = $_COOKIE['email'];

//slect
function selectSQL($SQL) {
    $dbhost = '124.156.134.23';  // mysql服务器主机地址
    $dbuser = 'omms';            // mysql用户名
    $dbpass = 'ajdts';          // mysql用户名密码
    $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
    if(! $conn ) {
        die('连接失败: ' . mysqli_error($conn));
    }
    // 设置编码，防止中文乱码
    mysqli_query($conn , "set names utf8");
    mysqli_select_db( $conn, 'online_maker_manage_system' );
    $retval = mysqli_query( $conn, $SQL );
    if(! $retval ) {
        die('无法读取数据: ' . mysqli_error($conn));
    }
    $i = 1;
    while($row = mysqli_fetch_array($retval)) {
        $res[$i] = $row;
        $i++;
    }
    return $res;
}

$sql2 = 'SELECT userId
        FROM useraccounts
        WHERE userEmail="'.$email.'"';
$res2 = selectSQL($sql2);
$userId = $res2[1][0];


$sql1 = 'SELECT comId
        FROM company
        WHERE comFir="'.$userId.'" || comSec="'.$userId.'" || comThi="'.$userId.'" || comFou="'.$userId.'" || comFif="'.$userId.'";';
$res1 = selectSQL($sql1);
$num = $res1[1][0];

$sql = 'SELECT *
    FROM company';
$row = selectSQL($sql);
$i = 1;
while(1) {
    if($i > $num) break;
    $Id[$i] = $row[$i][0];
    $Name[$i] = $row[$i][1];
    $Money[$i] = $row[$i][2];
    $Motto[$i] = $row[$i][3];
    $First[$i] = $row[$i][4];
    $tmpRow = selectSQL('SELECT userName FROM useraccounts WHERE userId = "'.$First[$i].'"');
    $FirstName[$i] = $tmpRow[1][0];
    $Second[$i] = $row[$i][5];
    $tmpRow = selectSQL('SELECT userName FROM useraccounts WHERE userId = "'.$Second[$i].'"');
    $SecondName[$i] = $tmpRow[1][0];
    $Third[$i] = $row[$i][6];
    $tmpRow = selectSQL('SELECT userName FROM useraccounts WHERE userId = "'.$Third[$i].'"');
    $ThirdName[$i] = $tmpRow[1][0];
    $Fourth[$i] = $row[$i][7];
    $tmpRow = selectSQL('SELECT userName FROM useraccounts WHERE userId = "'.$Fourth[$i].'"');
    $FourthName[$i] = $tmpRow[1][0];
    $Fifth[$i] = $row[$i][8];
    $tmpRow = selectSQL('SELECT userName FROM useraccounts WHERE userId = "'.$Fifth[$i].'"');
    $FifthName[$i] = $tmpRow[1][0];
    $CEO[$i] = $row[$i][9];
    $tmpRow = selectSQL('SELECT userName FROM useraccounts WHERE userId = "'.$CEO[$i].'"');
    $CEOName[$i] = $tmpRow[1][0];
    $i++;
}
include ("../static/html_table.class.php");
// create object
$mytbl = new html_table();
// General Table properties
$mytbl->width = "70%";             // set table width;
$mytbl->cellspacing = 1;         // 1 is class's default value
$mytbl->cellpadding = 4;        // 4 is class's default value
$mytbl->border = 0;             // 0 is class's default value
$mytbl->rowcolor = "blue";     // table's rows colors...default is #FFCC99


// Set table's header row
$mytbl->display_header_row = TRUE;       // enable the option. Default is FALSE
$mytbl->set_bold_labels = TRUE;             // Default is TRUE
$mytbl->set_header_font_color="#000000"; // Default is #000000
$mytbl->set_header_font_face="Tahoma";   // default is Tahoma
$mytbl->set_header_bgcolor ="#87CEFA";   // Default if $FFCC33

//Set row event
$mytbl->set_row_event = TRUE; // Default is FALSE
$mytbl->set_row_event_color = "#FF9900"; //Default is #9999FF

// Set table's rows alter colors
$mytbl->set_alter_colors = TRUE;        // Default is False
$mytbl->first_alter_color = "#E9E9E9"; // Default is #FFFFFF

// Add Font Tags in each cell
$mytbl->display_fonts = TRUE; // Default Is FALSE


// Builbing A Table - 4 colums, N rows

// 1st row Colspan 4
$myarr[0][0]["colspan"]= 10;
$myarr[0][0]["align"]  = "center";
$myarr[0][0]["text"]   = "公司详细信息";

$myarr[1][0]["text"]= "&nbsp";
$myarr[1][0]["align"]  = "center";
$myarr[1][0]["text"]="公司编号";
$myarr[1][1]["align"]  = "center";
$myarr[1][1]["text"]="公司名称";
$myarr[1][2]["align"]  = "center";
$myarr[1][2]["text"]="公司资金";
$myarr[1][3]["align"]  = "center";
$myarr[1][3]["text"]="公司格言";
$myarr[1][4]["align"]  = "center";
$myarr[1][4]["text"]="公司董事长";
$myarr[1][5]["align"]  = "center";
$myarr[1][5]["text"]="工程部";
$myarr[1][6]["align"]  = "center";
$myarr[1][6]["text"]="编程部";
$myarr[1][7]["align"]  = "center";
$myarr[1][7]["text"]="美术部";
$myarr[1][8]["align"]  = "center";
$myarr[1][8]["text"]="后勤部";
$myarr[1][9]["align"]  = "center";
$myarr[1][9]["text"]="宣传部";

$ti = $i - 1;
$myarr[2][0]["width"] = 50;
$myarr[2][0]["align"] = "center";
$myarr[2][0]["bgcolor"] = "red";
$myarr[2][0]["text"]  = $Id[$ti];
$myarr[2][1]["width"] = 200;
$myarr[2][1]["align"] = "center";
$myarr[2][1]["text"]  = "<a href='/company/?$ti'>".$Name[$ti]."</a>";
$myarr[2][2]["width"] = 100;
$myarr[2][2]["align"] = "center";
$myarr[2][2]["text"]  = $Money[$ti];
$myarr[2][3]["width"] = 300;
$myarr[2][3]["align"] = "center";
$myarr[2][3]["text"]  = $Motto[$ti];
$myarr[2][4]["width"] = 100;
$myarr[2][4]["align"] = "center";
$myarr[2][4]["text"]="<a href='/information/?".$CEO[$ti]."'>".$CEOName[$ti]."</a>";
$myarr[2][5]["width"] = 100;
$myarr[2][5]["align"]  = "center";
$myarr[2][5]["text"]="<a href='/information/?".$First[$ti]."'>".$FirstName[$ti]."</a>";
$myarr[2][6]["width"] = 100;
$myarr[2][6]["align"]  = "center";
$myarr[2][6]["text"]="<a href='/information/?".$Second[$ti]."'>".$SecondName[$ti]."</a>";
$myarr[2][7]["width"] = 100;
$myarr[2][7]["align"]  = "center";
$myarr[2][7]["text"]="<a href='/information/?".$Third[$ti]."'>".$ThirdName[$ti]."</a>";
$myarr[2][8]["width"] = 100;
$myarr[2][8]["align"]  = "center";
$myarr[2][8]["text"]="<a href='/information/?".$Fourth[$ti]."'>".$FourthName[$ti]."</a>";
$myarr[2][9]["width"] = 100;
$myarr[2][9]["align"]  = "center";
$myarr[2][9]["text"]="<a href='/information/?".$Fifth[$ti]."'>".$FifthName[$ti]."</a>";

// Building Html from array
$html = $mytbl->build_html_table( $myarr );

?>

<center>
    <div id="all" >
    <?php
    echo($html);
    ?>
    </div>
</center>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../footer.php";?>
<!-- 脚注 - 结束 -->