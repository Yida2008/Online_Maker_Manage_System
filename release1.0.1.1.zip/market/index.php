<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../style.php";?>
<!-- css - 结束 -->

</head>
<body class="stars"id="market">
<!-- 导航栏 - 开始 -->
<?php include "../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->

<a href="eng/">
<div class="banner-box" style="background-color:green; font-size:30px;">
    <img src="/static/engineering.png" hight="120px" width="160px">
    <dp style="position: relative; top:-25%;">工程</dp>
</div>
</a>

<a href="fax/">
<div class="banner-box" style="background-color:#ccffff; font-size:30px;">
    <img src="/static/fax.png" hight="120px" width="160px">
    <dp style="position: relative; top:-25%;">税收</dp>
</div>
</a>

<a href="ren/">
<div class="banner-box" style="background-color:orange; font-size:30px;">
    <img src="/static/ren.png" hight="120px" width="160px">
    <dp style="position: relative; top:-25%;">租借</dp>
</div>
</a>

<a href="man/">
<div class="banner-box" style="background-color:red; font-size:30px;">
    <img src="/static/man.png" hight="120px" width="160px">
    <dp style="position: relative; top:-25%;">市场监察</dp>
</div>
</a>

<a href="abo/">
<div class="banner-box" style="background-color:purple; font-size:30px;">
    <img src="/static/abo.png" hight="120px" width="160px">
    <dp style="position: relative; top:-25%;">违纪</dp>
</div>
</a>

<!-- 主体 - 结束 -->
</body>
<!-- 脚注 - 开始 -->
<?php include "../footer.php";?>
<!-- 脚注 - 结束 -->