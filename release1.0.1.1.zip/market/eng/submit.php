<?php
$comId = $_POST["comId"];
$engId = $_POST["engId"];
$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT count(*)
        FROM engstatus';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法插入数据: ' . mysqli_error($conn));
}
while($row=mysqli_fetch_row($retval)) {$num = $row[0];}
$num++;

$sql = 'INSERT INTO engstatus'.
        '(engId, comId, engStatus, statusId)'.
        'VALUES'.
        '("'.$engId.'","'.$comId.'", "0", "'.$num.'")';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法插入数据: ' . mysqli_error($conn));
}
header("Location:".getenv('HTTP_REFERER'));
?>