<?php

echo('<getfooter></getfooter><center><footer>Powered By <a href="http://maker.spacei.top">Online_Maker_Manage_System(OMMS)</a><br>
Supported By <a href="https://github.com/Yida2008">Yida_Xiang</a></footer></center>');
?>