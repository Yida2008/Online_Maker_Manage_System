﻿<!DOCTYPE html>
<html>
<head>
<meta charset="utf8">
<title>注册 - 在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "style.php";?>
<!-- css - 结束 --></head>
<body class="stars">
<!-- 导航栏 - 开始 -->
<?php include "header.php";?>
<!-- 导航栏 - 结束 -->
<form name="myForm" action="MakeAccounts.php" onsubmit="return validateForm();" method="post">
<div class="login-box" >
    <h1><center>注册</center></h1><br>
    <h2><center><font size=3>昵称: </font><input id="name" name="newname" type="textarea" /></center></h2><br><br>
    <h2><center><font size=3>邮箱: </font><input id="email" name="newmail" type="textarea" /></center></h2><br>
    <script>
        function validateForm(){
            var y=document.forms["myForm"]["name"].value;
            var x=document.forms["myForm"]["email"].value;
            var atpos=x.indexOf("@");
            var dotpos=x.lastIndexOf(".");
            if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length){
                alert("不是一个有效的 e-mail 地址");
                return false;
            }
        }
    </script><br>
    <h2><center><font size=3>密码: </font><input name="newpass" type="password" /></center></h2><br>
    <h2><center><input type="submit"/></center></h2>
</div>
</form>

<!-- 脚注 - 开始 -->
<?php include "footer.php";?>
<!-- 脚注 - 结束 -->

</html></body>