﻿<?php
error_reporting(0); 
$dbhost = '124.156.134.23';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$email = $_COOKIE["email"];
$sql = 'SELECT *
        FROM useraccounts
        WHERE userEmail= "' . $email . '" ';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$row=mysqli_fetch_array($retval);
$username=$row["userName"];
$ad=$row["isAdmin"];
// 释放内存
mysqli_free_result($retval);
mysqli_close($conn);

$userlogin=0;
if($username == null) {
    $userlogin = 0;
    if($_SERVER["REQUEST_URI"]!='/login.php' && $_SERVER["REQUEST_URI"]!='/account.php') header('Location: /login.php');
} else {
    $userlogin = 1;
}

echo('
<script>
document.addEventListener("DOMContentLoaded",function(){

      var duration = 750;

      // 样式string拼凑
      var forStyle = function(position){
        var cssStr = "";
        for( var key in position){
          if(position.hasOwnProperty(key)) cssStr += key+":"+position[key]+";";
        };
        return cssStr;
      }

      // 获取鼠标点击位置
      var forRect = function(target){
        var position = {
          top:0,
          left:0
        }, ele = document.documentElement;
        "undefined" != typeof target.getBoundingClientRect && (position = target.getBoundingClientRect());
        return {
            top: position.top + window.pageYOffset - ele.clientTop,
            left: position.left + window.pageXOffset - ele.clientLeft
        }
      }

      var show = function(event){
        var pDiv = event.target,
        cDiv = document.createElement("div");
        pDiv.appendChild(cDiv);
        var rectObj = forRect(pDiv),
          _height = event.pageY - rectObj.top,
          _left = event.pageX - rectObj.left,
          _scale = "scale(" + pDiv.clientWidth / 100 * 10 + ")";
        var position = {
          top: _height+"px",
          left: _left+"px"
        };
        cDiv.className = cDiv.className + " waves-animation",
        cDiv.setAttribute("style", forStyle(position)),
        position["-webkit-transform"] = _scale,
        position["-moz-transform"] = _scale,
        position["-ms-transform"] = _scale,
        position["-o-transform"] = _scale,
        position.transform = _scale,
        position.opacity = "1",
        position["-webkit-transition-duration"] = duration + "ms",
        position["-moz-transition-duration"] = duration + "ms",
        position["-o-transition-duration"] = duration + "ms",
        position["transition-duration"] = duration + "ms",
        position["-webkit-transition-timing-function"] = "cubic-bezier(0.250, 0.460, 0.450, 0.940)",
        position["-moz-transition-timing-function"] = "cubic-bezier(0.250, 0.460, 0.450, 0.940)",
        position["-o-transition-timing-function"] = "cubic-bezier(0.250, 0.460, 0.450, 0.940)",
        position["transition-timing-function"] = "cubic-bezier(0.250, 0.460, 0.450, 0.940)",
        cDiv.setAttribute("style", forStyle(position));
        var finishStyle = {
          opacity: 0,
          "-webkit-transition-duration": duration + "ms",
          "-moz-transition-duration": duration + "ms",
          "-o-transition-duration": duration + "ms",
          "transition-duration": duration + "ms",
          "-webkit-transform" : _scale,
          "-moz-transform" : _scale,
          "-ms-transform" : _scale,
          "-o-transform" : _scale,
          top: _height + "px",
          left: _left + "px",
        };
        setTimeout(function(){
          cDiv.setAttribute("style", forStyle(finishStyle));
          setTimeout(function(){
            pDiv.removeChild(cDiv);
          },duration);
        },100)
      }
      document.querySelector(".waves").addEventListener("click",function(e){
        show(e);
      },!1);
    },!1);
</script>
');

echo("
<script src='/static/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_HTMLorMML'></script> <script type=text/x-mathjax-config> MathJax.Hub.Config({
    extensions: ['tex2jax.js'],
    tex2jax: {
      inlineMath: [['$','$'], ['$$$', '$$$'], ['\\(','\\)']],
      displayMath: [['$$','$$'], ['\\[','\\]']],
      processEscapes: true,
      showProcessingMessages: false,
      messageStyle: 'none',
      processEnvironments: true,
      skipTags: [
        'script',
        'style',
        'textarea',
        'input',
        'code',
        'footer',
        'test',
        ],
      ignoreClass: 'CodeMirror|language-cpp|ace_editor|noJax',
      },
    });
     MathJax.Hub.Queue(['Typeset', MathJax.Hub]); </script> <script>function MathUpdate(){MathJax.Hub.Queue(['Typeset',MathJax.Hub])}setInterval(MathUpdate,300)</script>

<dl>
    <ni><a id='hom' href='/'>主页</a></ni>
    <ni><a id='com' href='/company'>公司</a></ni>
    <ni><a id='mar' href='/market'>交易市场</a></ni>
    
    <script>
        var hom=document.getElementById('hom');
        var com=document.getElementById('com');
        var mar=document.getElementById('mar');
        var ID=document.body.id;
        if(ID=='home') {
            hom.className='active';
        }
        if(ID=='company') {
            com.className='active';
        }
        if(ID=='market') {
            mar.className='active';
        }
        
    </script>

    <!--侧边栏-->
    <right>
        <a id='userid' class='waves' onclick=''>");
        if($userlogin==0) echo("未登录");
        else echo($username);
    echo("
		</a>
    </right>
</dl>");
if($userlogin==0) {
        echo("
    <follow id='1' hidden='true'>
        <a href='/login.php'>登录</a>
        <a href='/account.php'>注册</a>
    </follow>");
} else {
    if($ad==0) {
        echo("
    <follow id='1' hidden='true'>
        <a href='/logout.php'>退出登录</a>
        <a href='/information'>个人信息</a>
        <a href='/mycom'>我的公司</a>
    </follow>");
    } else {
        echo("
    <follow id='1' hidden='true'>
        <a href='/logout.php'>退出登录</a>
        <a href='/information'>个人信息</a>
        <a href='/mycom'>我的公司</a>
        <a href='/admin'>管理</a>
    </follow>
        ");
    }
}
echo("
<script>
    var flag = 0;
    var userid1=document.getElementById('userid');
    var f=document.getElementById('1');
    userid1.onclick = function(){ //当被点击，则显示
        if(flag) {
            flag = 0;
            f.hidden=true;
        } else {
            flag = 1;
            f.hidden=false;
        }
    }
</script>
<script src='http://cdn.bootcss.com/highlight.js/9.11.0/highlight.min.js'></script>
<script>hljs.initHighlightingOnLoad();</script>
<script src='http://cdn.bootcss.com/highlight.js/8.0/highlight.min.js'></script>
<script src='//cdn.bootcss.com/highlightjs-line-numbers.js/1.1.0/highlightjs-line-numbers.min.js'></script>
<script>hljs.initLineNumbersOnLoad();</script>
<script src=/static/pace/pace.min.js></script>
");


?>