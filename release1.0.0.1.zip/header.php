<?php
error_reporting(0); 
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$email = $_COOKIE["email"];
$sql = 'SELECT *
        FROM useraccounts
        WHERE userEmail= "' . $email . '" ';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
$row=mysqli_fetch_array($retval);
$username=$row["userName"];
$ad=$row["isAdmin"];
// 释放内存
mysqli_free_result($retval);
mysqli_close($conn);

$userlogin=0;
if($username == null) {
    $userlogin = 0;
    if($_SERVER["REQUEST_URI"]!='/login.php' && $_SERVER["REQUEST_URI"]!='/account.php') header('Location: /login.php');
} else {
    $userlogin = 1;
}

echo('
<link href="/static/pace/themes/green/pace-theme-flash.css" rel="stylesheet" />
<script src=/static/pace/pace.min.js></script>
');

echo("

<script src='/static/jquery.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-AMS-MML_HTMLorMML'></script> <script type=text/x-mathjax-config> MathJax.Hub.Config({
    extensions: ['tex2jax.js'],
    tex2jax: {
      inlineMath: [['$','$'], ['$$$', '$$$'], ['\\(','\\)']],
      displayMath: [['$$','$$'], ['\\[','\\]']],
      processEscapes: true,
      showProcessingMessages: false,
      messageStyle: 'none',
      processEnvironments: true,
      skipTags: [
        'script',
        'style',
        'textarea',
        'input',
        'code',
        'footer',
        'test',
        ],
      ignoreClass: 'CodeMirror|language-cpp|ace_editor|noJax',
      },
    });
     MathJax.Hub.Queue(['Typeset', MathJax.Hub]); </script> <script>function MathUpdate(){MathJax.Hub.Queue(['Typeset',MathJax.Hub])}setInterval(MathUpdate,300)</script>

<dl>
    <ni><a id='hom' href='/'>主页</a></ni>
    <ni><a id='com' href='/company'>公司</a></ni>
    <ni><a id='mar' href='/market'>交易市场</a></ni>
    
    <script>
        var hom=document.getElementById('hom');
        var com=document.getElementById('com');
        var mar=document.getElementById('mar');
        var ID=document.body.id;
        if(ID=='home') {
            hom.className='active';
        }
        if(ID=='company') {
            com.className='active';
        }
        if(ID=='market') {
            mar.className='active';
        }
        
    </script>

    <!--侧边栏-->
    <right>
        <a id='userid' onclick=''>");
        if($userlogin==0) echo("未登录");
        else echo($username);
    echo("
		</a>
    </right>
</dl>");
if($userlogin==0) {
        echo("
    <follow id='1' hidden='true'>
        <a href='/login.php'>登录</a>
        <a href='/account.php'>注册</a>
    </follow>");
} else {
    if($ad==0) {
        echo("
    <follow id='1' hidden='true'>
        <a href='/logout.php'>退出登录</a>
        <a href='/information'>个人信息</a>
        <a href='/mycom'>我的公司</a>
    </follow>");
    } else {
        echo("
    <follow id='1' hidden='true'>
        <a href='/logout.php'>退出登录</a>
        <a href='/information'>个人信息</a>
        <a href='/mycom'>我的公司</a>
        <a href='/admin'>管理</a>
    </follow>
        ");
    }
}
echo("
<script>
    var flag = 0;
    var userid1=document.getElementById('userid');
    var f=document.getElementById('1');
    userid1.onclick = function(){ //当被点击，则显示
        if(flag) {
            flag = 0;
            f.hidden=true;
        } else {
            flag = 1;
            f.hidden=false;
        }
    }
</script>
<script src='http://cdn.bootcss.com/highlight.js/9.11.0/highlight.min.js'></script>
<script>hljs.initHighlightingOnLoad();</script>
<script src='http://cdn.bootcss.com/highlight.js/8.0/highlight.min.js'></script>
<script src='//cdn.bootcss.com/highlightjs-line-numbers.js/1.1.0/highlightjs-line-numbers.min.js'></script>
<script>hljs.initLineNumbersOnLoad();</script>

");


?>