<?php
$Id = $_POST["Id"];
$Email = $_COOKIE["email"];
$Texts = $_POST["Texts"];
date_default_timezone_set("Asia/Shanghai");
$Time = date("Y-m-d H:i:s");
$Title = $_POST["Title"];
$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
mysqli_select_db( $conn, 'online_maker_manage_system' );
$SQL = 'UPDATE userannouncement
        SET Email="'.$Email.'", 
        Texts="'.$Texts.'", 
        textTime="'.$Time.'", 
        Title="'.$Title.'"
        WHERE Id="'.$Id.'";';
$retval = mysqli_query( $conn, $SQL );
if(! $retval ) {
    die('无法更新数据: ' . mysqli_error($conn));
}
header("Location: /admin/announce/modify/");
?>