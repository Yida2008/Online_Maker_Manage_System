<?php
$engId = $_POST["engId"];
$comId = $_POST["comId"];
if ($_FILES["file"]["error"] > 0) {
    echo "错误：: " . $_FILES["file"]["error"] . "<br>";
} else {
    $file_type=$_FILES["file"]["type"];
    for ($i = 0; $i < strlen($file_type); $i++) {
        if($file_type[$i] == '/') $pos = $i+1;
    }
    $file_type=substr($file_type, $pos, strlen($file_type) - $pos);
    $file_name = md5($_FILES["file"]["name"]).".".$file_type;
    // 将文件上传到 upload 目录下
    move_uploaded_file($_FILES["file"]["tmp_name"], "C:/xampp/htdocs/upload/".$file_name);
}


$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'UPDATE engstatus
        SET engWork="'.$file_name.'"
        WHERE engId="'.$engId.'" && comId="'.$comId.'"';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法插入数据: ' . mysqli_error($conn));
}
header("Location:".getenv('HTTP_REFERER'));
?>