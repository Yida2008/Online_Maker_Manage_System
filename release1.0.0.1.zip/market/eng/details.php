<!DOCTYPE html>
<head>
<title>在线创客管理系统</title>
<!-- css - 开始 -->
<?php include "../../style.php";?>
<!-- css - 结束 -->

</head>
<body id="market">
<!-- 导航栏 - 开始 -->
<?php include "../../header.php";?>
<!-- 导航栏 - 结束 -->

<!-- 主体 - 开始 -->
<?php

$dbhost = 'localhost';  // mysql服务器主机地址
$dbuser = 'omms';            // mysql用户名
$dbpass = 'ajdts';          // mysql用户名密码
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
if(! $conn ) {
    die('连接失败: ' . mysqli_error($conn));
}
// 设置编码，防止中文乱码
mysqli_query($conn , "set names utf8");
$sql = 'SELECT count(*)
        FROM company';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}

$row = mysqli_fetch_row($retval);
$n = $row[0];

$url = $_SERVER["REQUEST_URI"];
$tmp=0;
for ($i = strlen($url)-1; $i >= 0; $i--) {
    if($url[$i] == '?') {
        $tmp=$i+1;
        break;
    }
}

$num = 0;
$tnum = 1;

for ($i = $tmp; $i < strlen($url); $i++) {
    $num += $tnum * ($url[$i] - '0');
    $tnum *= 10;
}

if($num == 0 || $num > $n) {
    header("Location: /company/");
} else {
    $sql = 'SELECT *
            FROM engineering';

    mysqli_select_db( $conn, 'online_maker_manage_system' );
    $retval = mysqli_query( $conn, $sql );
    if(! $retval ) {
        die('无法读取数据: ' . mysqli_error($conn));
    }

    include ("../../static/html_table.class.php");
    // create object
    $mytbl = new html_table();
    // General Table properties
    $mytbl->width = "60%";             // set table width;
    $mytbl->cellspacing = 1;         // 1 is class's default value
    $mytbl->cellpadding = 4;        // 4 is class's default value
    $mytbl->border = 0;             // 0 is class's default value
    $mytbl->rowcolor = "blue";     // table's rows colors...default is #FFCC99

    // Set table's header row
    $mytbl->display_header_row = TRUE;       // enable the option. Default is FALSE
    $mytbl->set_bold_labels = TRUE;             // Default is TRUE
    $mytbl->set_header_font_color="#000000"; // Default is #000000
    $mytbl->set_header_font_face="Tahoma";   // default is Tahoma
    $mytbl->set_header_bgcolor ="#FF9933";   // Default if $FFCC33

    //Set row event
    $mytbl->set_row_event = TRUE; // Default is FALSE
    $mytbl->set_row_event_color = "#FF9900"; //Default is #9999FF

    // Set table's rows alter colors
    $mytbl->set_alter_colors = TRUE;        // Default is False
    $mytbl->first_alter_color = "#E9E9E9"; // Default is #FFFFFF

    // Add Font Tags in each cell
    $mytbl->display_fonts = TRUE; // Default Is FALSE


    // Builbing A Table - 4 colums, N rows

    // 1st row Colspan 4
    $myarr[0][0]["colspan"]= 4;
    $myarr[0][0]["align"]  = "center";
    $myarr[0][0]["text"]   = "项目列表";

    $myarr[1][0]["text"]= "&nbsp";
    $myarr[1][0]["align"]  = "center";
    $myarr[1][0]["text"]="项目编号";
    $myarr[1][1]["align"]  = "center";
    $myarr[1][1]["text"]="项目名称";
    $myarr[1][2]["align"]  = "center";
    $myarr[1][2]["text"]="项目丙方";
    $myarr[1][3]["align"]  = "center";
    $myarr[1][3]["text"]="项目报酬";

    ##########embeded table##########################
    $i = 2;
    while($row=mysqli_fetch_row($retval)) {
        if($i - 2 == $num) break;
        $ti = $i - 1;
        $engId = $row[0];
        $engName = $row[1];
        $Bing = $row[2];
        $Money = $row[3];
        if($Bing == 0) $Bing = "暂无人员";
        else {
            $sql = 'SELECT userName
                    FROM useraccounts
                    WHERE userId="'.$ti.'"';

            mysqli_select_db( $conn, 'online_maker_manage_system' );
            $resualt = mysqli_query( $conn, $sql );
            if(! $resualt ) {
                die('无法读取数据: ' . mysqli_error($conn));
            }
            while($res = mysqli_fetch_row($resualt)){$BingName = $res[0];}
            $Bing = "<a href='/market/eng/?$ti'>$BingName</a>";
        }
        $i++;
    }
}

?>
<div style="display: inline-block;margin-left:25%;color:white;margin-top:3%;border-radius:5px; width:40%; height:17%; background-color:blue;" >
    <?php
    $ti = $i - 2;
    echo("<br>项目编号:  ".$engId.
    "<br>项目名称:  ".
    "<a href='/market/eng/?$ti'>$engName</a>".
    "<br>项目丙方:  ".$Bing.
    "<br>项目报酬:  ".$Money);
    ?>
</div>

<?php
$sql = 'SELECT userId
        FROM useraccounts
        WHERE userEmail="'.$email.'"';

$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据: ' . mysqli_error($conn));
}
while($row=mysqli_fetch_row($retval)) {
    $userId = $row[0];
}

$sql = 'SELECT *
        FROM company
        WHERE comFir="'.$userId.'"'.' || '.
        'comSec="'.$userId.'"'.' || '.
        'comThi="'.$userId.'"'.' || '.
        'comFou="'.$userId.'"'.' || '.
        'comFif="'.$userId.'";';

$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据4: ' . mysqli_error($conn));
}
$i = 1;
while($row = mysqli_fetch_row($retval)) {
    if($userId == $First || $userId == $Second || $userId == $Third || $userId == $Fourth || $userId == $Fifth) {
        $comId = $Id;
        break;
    }
    $Id = $row[0];
    $comName = $row[1];
    $Money = $row[2];
    $Motto = $row[3];
    $First = $row[4];
    $Second = $row[5];
    $Third = $row[6];
    $Fourth = $row[7];
    $Fifth = $row[8];
    $CEO = $row[9];
    $i++;
}

$sql = 'SELECT *
        FROM engstatus
        WHERE engId="'.$engId.'" && comId="'.$comId.'"';
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据3: ' . mysqli_error($conn));
}
$flag = 0;
while($row = mysqli_fetch_row($retval)) {
    $flag = 1;
}
?>

<div style="position: relative;display: inline-block;margin-left:25%;color:white;margin-top:3%;border-radius:5px; width:40%; min-height:17%; background-color:purple;" >
<?php
$sql = 'SELECT *
        FROM engstatus
        WHERE engId = "'.$engId.'"';

mysqli_select_db( $conn, 'online_maker_manage_system' );
$retval = mysqli_query( $conn, $sql );
if(! $retval ) {
    die('无法读取数据1: ' . mysqli_error($conn));
}
##########embeded table##########################
echo("参与公司: <br>");
$i = 2;
while($row=mysqli_fetch_row($retval)) {
    $tmpCom = $row[1];
    $sql = 'SELECT comName
            FROM company
            WHERE comId = "'.$tmpCom.'"';

    mysqli_select_db( $conn, 'online_maker_manage_system' );
    $resualt = mysqli_query( $conn, $sql );
    if(! $resualt ) {
        die('无法读取数据2: ' . mysqli_error($conn));
    }
    while($res=mysqli_fetch_row($resualt)) {$tmpComName = $res[0];}
    $tmpEng = $row[0];
    echo($i - 1);
    echo(".");
    echo("<a href='/company/?".$tmpCom."'>".$tmpComName.'</a>'.'<br>');
    $i++;
}
?>
</div>


<form action = "submit.php" method = "post">
<input type="submit" value = "<?php if($flag) echo("已报名");else if($userId == $CEO) echo("点击报名"); else echo("权限不足!");?>" style="border: none;display: inline-block;margin-left:25%;color:white;margin-top:3%;border-radius:5px; width:40%; height:17%; background-color:green;" <?php if($flag || $userId != $CEO) echo('disabled="true"');?> />
<input name = "comId" hidden = "true" value="<?php echo($comId);?>" />
<input name = "engId" hidden = "true" value="<?php echo($engId);?>" />
</form>
<?php
if($flag) {
    echo('<form action = "submitWork.php" method = "post" enctype="multipart/form-data">
    <input type="file" value="上传文件" name="file" id="file" /><br>
    <input type="submit" value = "点击上传工程文件" style="border: none;display: inline-block;margin-left:25%;color:white;margin-top:3%;border-radius:5px; width:40%; height:17%; background-color:green;" />
    <input name = "comId" hidden = "true" value="'.$comId.'" />
    <input name = "engId" hidden = "true" value="'.$engId.'" />
    </form>');
}
?>

<!-- 主体 - 结束 -->

</body>
<!-- 脚注 - 开始 -->
<?php include "../../footer.php";?>
<!-- 脚注 - 结束 -->